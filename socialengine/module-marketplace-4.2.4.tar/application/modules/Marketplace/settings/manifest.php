<?php
/**
 * 
 *
 * @category   Application_Extensions
 * @package    Marketplace
 * @copyright  Copyright 2010 
 * * 
 * @version    $Id: manifest.php 7250 2010-09-01 07:42:35Z john $
 * 
 */
return array(
  // Package -------------------------------------------------------------------
//  'package' => array(
//    'type' => 'module',
//    'name' => 'marketplace',
//    'version' => '4.0.9',
//    'revision' => '$Revision: 7250 $',
//    'path' => 'application/modules/Marketplace',
//    'repository' => 'socialengine.net',
//    'date'=> 'Wed, 10 Nov 2010 19:34:29 +0000',
//    'title' => 'Marketplaces',
//    'description' => 'Marketplaces',
//    'author' => 'Marketplaces',
//
//    'meta' => array(
//      'title' => 'Marketplaces',
//      'description' => 'Marketplaces',
//      'author' => 'Marketplaces',
//      //'changeLog' => '', //array(
//
//  ),
//    'actions' => array(
//       'install',
//       'upgrade',
//       'refresh',
//       'enable',
//       'disable',
//     ),

    'package' => array(
    'type' => 'module',
    'name' => 'marketplace',
    'version' => '4.2.4',
    'revision' => '$Revision: 7260 $',
    'path' => 'application/modules/Marketplace',
    'repository' => 'socialengine.net',
    'meta' => array(
      'title' => 'Marketplace',
      'description' => 'Marketplace',
      'author' => 'SocialEngineMarket',
      'changeLog' => array(
        '4.2.4' => array(
          'controllers/AdminManageController.php' => 'First Version',
        ),
      ),
    ),
    'actions' => array(
       'install',
       'upgrade',
       'refresh',
       'enable',
       'disable',
     ),
    'callback' => array(
      'path' => 'application/modules/Marketplace/settings/install.php',
      'class' => 'Marketplace_Installer',
    ),
    'directories' => array(
      'application/modules/Marketplace',
    ),
    'files' => array(
      'application/languages/en/marketplace.csv',
    ),
  ),
  // Hooks ---------------------------------------------------------------------
  'hooks' => array(
    array(
      'event' => 'onStatistics',
      'resource' => 'Marketplace_Plugin_Core'
    ),
    array(
      'event' => 'onUserDeleteBefore',
      'resource' => 'Marketplace_Plugin_Core',
    ),
  ),
  // Items ---------------------------------------------------------------------
  'items' => array(
    'marketplace',
    'marketplace_album',
    'marketplace_photo'
  ),
  // Routes --------------------------------------------------------------------
  'routes' => array(
    'marketplace_extended' => array(
      'route' => 'marketplaces/:controller/:action/*',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'index',
      ),
      'reqs' => array(
        'controller' => '\D+',
        'action' => '\D+',
      )
    ),
    // Public
    'marketplace_browse' => array(
      'route' => 'marketplaces/browse/:category/:page/*',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'index',
        'category' => 0,
        'page' => 1
      )
    ),
    'marketplace_view' => array(
      'route' => 'marketplaces/:user_id/*',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'list'
      ),
      'reqs' => array(
        'user_id' => '\d+'
      )
    ),
    'marketplace_entry_view' => array(
      'route' => 'marketplaces/:user_id/:marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'view'
      ),
      'reqs' => array(
        'user_id' => '\d+',
        'marketplace_id' => '\d+'
      )
    ),
//      'marketplace_category' => array(
//      'route' => 'marketplaces/browse/category/:category_id',
//      'defaults' => array(
//        'module' => 'marketplace',
//        'controller' => 'index',
//        'action' => 'index'
//      )
//    ),
    // User
    'marketplace_create' => array(
      'route' => 'marketplaces/create',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'create'
      )
    ),
    'marketplace_reports' => array(
      'route' => 'marketplaces/reports/:page',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'reports',
        'page' => '1'
      )
    ),
    'marketplace_delete' => array(
      'route' => 'marketplaces/delete/:marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'delete'
      )
    ),
    'marketplace_close' => array(
      'route' => 'marketplaces/close/:marketplace_id/:closed',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'close'
      )
    ),
    'marketplace_edit' => array(
      'route' => 'marketplaces/edit/:marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'edit'
      )
    ),
    'marketplace_manage' => array(
      'route' => 'marketplaces/manage/:page',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'manage',
        'page' => '1'
      )
    ),
    'marketplace_success' => array(
      'route' => 'marketplaces/success/:marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'success'
      )
    ),
    'marketplace_paypal' => array(
      'route' => 'marketplaces/paypal/:page',//marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'paypal'
      )
    ),

      'marketplace_payment' => array(
      'route' => 'marketplaces/payment/:page',//marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'payment',
        'page'   => 0,
      )
    ),

      'marketplace_paymentnotify' => array(
      'route' => 'marketplaces/paymentnotify/:page',//marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'paymentnotify',
        'page'   => 0,
      )
    ),
      'marketplace_paymentreturn' => array(
      'route' => 'marketplaces/paymentreturn/:page',//marketplace_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'paymentreturn',
        'page'   => 0,
      )
    ),
    'marketplace_style' => array(
      'route' => 'marketplaces/marketplacestyle',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'marketplacestyle'
      )
    ),

    'marketplace_tag' => array(
      'route' => 'marketplaces/tag',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'index',
        'action' => 'suggest'
      )
    ),

    /*
	*/
	'marketplace_category' => array(
      'route' => 'admin/marketplace/settings/categories/:category_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'admin-settings',
        'action' => 'categories',
        'category_id' => 0
      )
    ),

//      'marketplace_addcategory' => array(
//      'route' => 'admin/marketplace/settings/add-category/:category_id',
//      'defaults' => array(
//        'module' => 'marketplace',
//        'controller' => 'AdminSettings',
//        'action' => 'addCategory',
//        'category_id' => 0
//      )
//    ),


    'marketplace_admin_manage_level' => array(
      'route' => 'admin/marketplace/level/:level_id',
      'defaults' => array(
        'module' => 'marketplace',
        'controller' => 'admin-level',
        'action' => 'index',
        'level_id' => 1
      )
    ),

  ),
);
