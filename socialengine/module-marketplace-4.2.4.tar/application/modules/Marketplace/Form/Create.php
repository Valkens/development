<?php

/**
 * 
 *
 * @category   Application_Extensions
 * @package    Marketplace
 * @copyright  Copyright 2010 
 * * 
 * @version    $Id: Create.php 7244 2010-09-01 01:49:53Z john $
 * 
 */

/**
 * @category   Application_Extensions
 * @package    Marketplace
 * @copyright  Copyright 2010 
 * * 
 */
class Marketplace_Form_Create extends Engine_Form
{
  public function init()
  {
    $this->setTitle('Post New Listing')
      ->setDescription('Compose your new marketplace listing below, then click "Post Listing" to publish the listing.')
      ->setAttrib('name', 'marketplaces_create');

    $this->addElement('Text', 'title', array(
      'label' => 'Listing Title',
      'allowEmpty' => false,
      'required' => true,
      'filters' => array(
        'StripTags',
        new Engine_Filter_Censor(),
        new Engine_Filter_StringLength(array('max' => '63')),
      ),
    ));

        $this->addElement('Text', 'price', array(
      'label' => 'Price',
      'allowEmpty' => false,
      'required' => true,
      'filters' => array(
        'StripTags',
        new Engine_Filter_Censor(),
        new Engine_Filter_StringLength(array('max' => '63')),
      ),
                      'validators' => array(
        array('NotEmpty', true),
       // array('EmailAddress', true),
		//array('Int', true),
		array('Float', true),
       ),
    ));

    $user = Engine_Api::_()->user()->getViewer();
    $user_level = Engine_Api::_()->user()->getViewer()->level_id;

    // init to
//    $this->addElement('Text', 'tags', array(
//      'label' => 'Tags (Keywords)',
//      'autocomplete' => 'off',
//      'description' => 'Separate tags with commas.',
//      'filters' => array(
//        new Engine_Filter_Censor(),
//      ),
//    ));
//    $this->tags->getDecorator("Description")->setOption("placement", "append");

    //$a_tree = Engine_Api::_()->marketplace()->tree_list_load_subtree('0');
    $a_tree = Engine_Api::_()->marketplace()->tree_list_load_all(); // tree_list_load_array(array(0));
     //print_r($a_tree);
   // print_r($a_tree);
    Engine_Api::_()->marketplace()->tree_select($a_tree,'',1);

    $newcategories = Engine_Api::_()->marketplace()->gettemp();
//    foreach( $newcategories as $k=>$e)//$category )
//    {
//      $form->category->addMultiOption($k,$e);//$category->category_id, $category->category_name);
//    }
   // print_r($newcategories);
   //
    // prepare categories
    $categories = Engine_Api::_()->marketplace()->getCategories();
    if( count($categories) != 0 ) {
      $categories_prepared[0] = "";
      foreach( $newcategories as $k=>$e) {//$category ) {
        //$categories_prepared[$category->category_id] = $category->category_name;
          $categories_prepared[$k] = $e;
      }

      // category field
      $this->addElement('Select', 'category_id', array(
        'label' => 'Category',
        'multiOptions' => $categories_prepared
      ));
    }

    $this->addElement('Textarea', 'body', array(
      'label' => 'Description',
      'filters' => array(
        'StripTags',
        new Engine_Filter_HtmlSpecialChars(),
        new Engine_Filter_EnableLinks(),
        new Engine_Filter_Censor(),
      ),
    ));

    

    $allowed_upload = Engine_Api::_()->authorization()->getPermission($user_level, 'marketplace', 'photo');
    if( $allowed_upload ) {
      $this->addElement('File', 'photo', array(
        'label' => 'Main Photo'
      ));
      $this->photo->addValidator('Extension', false, 'jpg,png,gif');
    }


//    $this->addElement('Text', 'price', array(
//      'label' => 'Price',
//      'allowEmpty' => false,
//      'required' => true,
//     // 'description'=> 'USD',
//       // 'config'=>'{"unit":"USD"}',
//      'filters' => array(
//        'StripTags',
//        new Engine_Filter_Censor(),
//        new Engine_Filter_StringLength(array('max' => '63')),
//      ),
//    ));
//     $this->price->getDecorator('Description')->setOption('placement', 'append');

      $this->addElement('Text', 'business_email', array(
      'label' => 'Business Email',
      'allowEmpty' => false,
      'required' => true,
     // 'description'=> 'USD',
        'config'=>'{"unit":"USD"}',
      'filters' => array(
        'StripTags',
        new Engine_Filter_Censor(),
        new Engine_Filter_StringLength(array('max' => '63')),
      ),
          'validators' => array(
        array('NotEmpty', true),
        array('EmailAddress', true),
              //array('Alnum', true),
       ),
    ));
     $this->business_email->getDecorator('Description')->setOption('placement', 'append');

    // Add subforms
//    if( !$this->_item ) {
//      $customFields = new Marketplace_Form_Custom_Fields();
//    } else {
//      $customFields = new Marketplace_Form_Custom_Fields(array(
//        'item' => $this->getItem()
//      ));
//    }
//
//    $this->addSubForms(array(
//      'fields' => $customFields
//    ));

    // Privacy
    $availableLabels = array(
      'everyone' => 'Everyone',
      'owner_network' => 'Friends and Networks',
      'owner_member_member' => 'Friends of Friends',
      'owner_member' => 'Friends Only',
      'owner' => 'Just Me'
    );
    // Add subforms
    if( !$this->_item ) {
      $customFields = new Marketplace_Form_Custom_Fields();
    } else {
      $customFields = new Marketplace_Form_Custom_Fields(array(
        'item' => $this->getItem()
      ));
    }

    $this->addSubForms(array(
      'fields' => $customFields
    ));
    // View
    $view_options = (array) Engine_Api::_()->authorization()->getAdapter('levels')->getAllowed('marketplace', $user, 'auth_view');
    $view_options = array_intersect_key($availableLabels, array_flip($view_options));

    if( count($view_options) >= 1 ) {
      $this->addElement('Select', 'auth_view', array(
        'label' => 'Privacy',
        'description' => 'Who may see this marketplace listing?',
        'multiOptions' => $view_options,
        'value' => key($view_options),
      ));
      $this->auth_view->getDecorator('Description')->setOption('placement', 'append');
    }

    // Comment
    $comment_options = (array) Engine_Api::_()->authorization()->getAdapter('levels')->getAllowed('marketplace', $user, 'auth_comment');
    $comment_options = array_intersect_key($availableLabels, array_flip($comment_options));

    if( count($comment_options) >= 1 ) {
      $this->addElement('Select', 'auth_comment', array(
        'label' => 'Comment Privacy',
        'description' => 'Who may post comments on this marketplace listing?',
        'multiOptions' => $comment_options,
        'value' => key($comment_options),
      ));
      $this->auth_comment->getDecorator('Description')->setOption('placement', 'append');
    }

    $this->addElement('Button', 'submit', array(
      'label' => 'Post Listing',
      'type' => 'submit',
      'decorators' => array(array('ViewScript', array(
        'viewScript' => '_formButtonCancel.tpl',
        'class' => 'form element'
      )))
    ));
  }

}