<?php
class Book_Model_DbTable_Params extends Engine_Db_Table
{
  protected $_rowClass = 'Book_Model_Param';
}