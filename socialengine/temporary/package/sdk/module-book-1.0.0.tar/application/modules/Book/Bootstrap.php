<?php

class Book_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}