<?php
class Book_Model_Param extends Core_Model_Item_Abstract
{
 
}